#!/usr/bin/env bash
# Reproduce every reported result, in dependency order.
#
#   ./run_all.sh /path/to/data /path/to/results /path/to/figures
#
# Expect several hours in total. Scripts 01, 02, 03 and 08 checkpoint after
# every fold or replicate, so an interrupted run resumes where it stopped.
set -euo pipefail

DATA="${1:?usage: run_all.sh DATA_DIR RESULTS_DIR FIGURES_DIR}"
RESULTS="${2:?}"
FIGURES="${3:?}"
cd "$(dirname "$0")/src"

echo "== 06  survey design: weighting, clustering, design effects  (Table A4)"
python 06_survey_design.py      "$DATA" "$RESULTS"
echo "== 07  configuration cross-test and disjoint blocks          (Table A7)"
python 07_config_crosstest.py   "$DATA" "$RESULTS"
echo "== 04  imbalance ablation and per-class metrics        (Tables A1, A2)"
python 04_imbalance_ablation.py "$DATA" "$RESULTS"
echo "== 05  equal-sample-size control                           (Table A3)"
python 05_equal_n_control.py    "$DATA" "$RESULTS"
echo "== 01  nested cross-validation                   (Table 1, ROC curves)"
python 01_nested_cv.py          "$DATA" "$RESULTS"
echo "== 02  baseline classifiers                                (Table A5)"
python 02_baselines.py          "$DATA" "$RESULTS"
echo "== 03  group-fold and temporal validation                  (Table A6)"
python 03_validation_design.py  "$DATA" "$RESULTS"
echo "== 08  attribution with design-bootstrap intervals  (Tables 2,3,4,5)"
python 08_attribution_bootstrap.py "$DATA" "$RESULTS"
echo "== 09  figures"
python 09_figures.py            "$RESULTS" "$FIGURES"
echo "done"
