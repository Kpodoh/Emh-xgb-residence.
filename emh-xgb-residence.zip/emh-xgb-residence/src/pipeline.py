"""
Shared pipeline components for the EMH-XGB residence analysis.

Every analysis script in this repository imports its preprocessing, feature
selection, class weighting and model construction from here, so that the
procedure described in the manuscript is defined in exactly one place.

Reference: Sections 2.4-2.7 of the manuscript.
"""
from __future__ import annotations
import os
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.inspection import permutation_importance
from sklearn.preprocessing import LabelEncoder
from sklearn.utils.class_weight import compute_class_weight
import xgboost as xgb

# ----------------------------------------------------------------- constants
SEED = 42
N_SELECT = 59
RESIDENCE = ["rural", "nonmetro", "region"]
CLASSES = ["FS", "MFS", "LFS", "VLFS"]          # high, marginal, low, very low
REGIONS = {1: "Northeast", 2: "Midwest", 3: "South", 4: "West"}

# Enrolment-month membership of each nested window (Section 2.3).
# FAPS enrolment months present in the data are {1,4,5,6,7,8,9,10,11,12};
# months 2 and 3 contain no households.
WINDOWS = {
    "H1": None,                       # all enrolment months, N = 4,826
    "H2": {1, 4, 5, 6, 7, 8, 9},      # months 1-9,            N = 3,518
    "H3": {1, 4, 5, 6},               # months 1-6,            N = 1,345
}

# Disjoint enrolment blocks used for the seasonal-composition check
# (Section 3.3; Table A7, Panel B).
BLOCKS = {
    "m1-6":   {1, 4, 5, 6},
    "m7-9":   {7, 8, 9},
    "m10-12": {10, 11, 12},
}

# Columns excluded from the predictor pool a priori (Sections 2.1 and 2.2):
# the outcome and everything algebraically derived from it, the survey design
# and administrative fields, and the enrolment month that defines the windows.
EXCLUDE = [
    # outcome and outcome-derived
    "adltfscat", "adltfsraw", "foodsufficient",
    *[f"foodsecureq{i}" for i in range(1, 11)],
    # survey design and identifiers
    "hhnum", "hhwgt", "tsstrata", "tspsu",
    # survey administration / field-period fields
    "targetgroup", "initintrvmon", "initfinaldays", "initialdate_flag",
    "startdate_edit", "startlag", "matchconsenthh", "startmon",
]

# Common model configuration used for every explanation model, at every
# window (Section 2.7). Holding this fixed is what makes attributions from
# different windows comparable; see Table A7.
COMMON_XGB = dict(
    objective="multi:softprob", num_class=4, eval_metric="mlogloss",
    random_state=SEED, verbosity=0, tree_method="hist", n_jobs=-1,
    gamma=0.1, reg_lambda=1.5, subsample=0.8, colsample_bytree=0.8,
    n_estimators=200, max_depth=5, learning_rate=0.05,
)

# The two per-window configurations crossed in the configuration test
# (Table A7, Panel A). Configuration A is COMMON_XGB.
CONFIGS = {
    "A": dict(n_estimators=200, max_depth=5, learning_rate=0.05),
    "B": dict(n_estimators=300, max_depth=4, learning_rate=0.01),
}

# Hyperparameter grid for the inner tuning loop (Section 2.6).
GRID = {
    "n_estimators": [100, 200, 300], "max_depth": [3, 5, 7],
    "learning_rate": [0.01, 0.05, 0.1], "subsample": [0.8, 1.0],
    "colsample_bytree": [0.8, 1.0], "gamma": [0, 0.1, 0.5],
    "reg_lambda": [1, 1.5, 2],
}
N_ITER_INNER = 20

# Permutation repetitions. The full-sample panel used 30; the in-fold
# re-derivation uses 8 for tractability (Section 2.4).
R_FULL_SAMPLE = 30
R_IN_FOLD = 8


# --------------------------------------------------------------------- data
def data_dir() -> str:
    """Directory holding faps_final.csv and faps_selected_features_59.csv.

    Set via the EMH_DATA environment variable, or passed as the first
    command-line argument by each script.
    """
    d = os.environ.get("EMH_DATA")
    if not d:
        raise SystemExit(
            "Set EMH_DATA to the directory containing faps_final.csv, "
            "or pass it as the first argument."
        )
    return d


def load_window(data: str, window: str) -> pd.DataFrame:
    """Return the households belonging to one nested enrolment window."""
    df = pd.read_csv(os.path.join(data, "faps_final.csv"), low_memory=False)
    months = WINDOWS[window]
    if months is not None:
        df = df[df["startmon"].isin(months)]
    return df.reset_index(drop=True)


def load_panel(data: str) -> list[str]:
    """The locked 59-predictor panel used for the explanation models."""
    path = os.path.join(data, "faps_selected_features_59.csv")
    return pd.read_csv(path)["Variable"].str.strip().tolist()


def predictor_pool(df: pd.DataFrame) -> list[str]:
    """Candidate predictors: everything not excluded a priori."""
    return [c for c in df.columns if c not in EXCLUDE]


def target(df: pd.DataFrame) -> pd.Series:
    """Four-class food security status, mapped to 0-3."""
    return (df["adltfscat"].astype(int) - 1).reset_index(drop=True)


# ------------------------------------------------------------ preprocessing
def encode(train: pd.DataFrame, test: pd.DataFrame):
    """Integer-encode object columns, fitting on the training partition only.

    Levels absent from the training fold are mapped to a reference training
    category, so no held-out fold can introduce an unseen level.
    """
    train, test = train.copy(), test.copy()
    for c in train.select_dtypes(include=["object"]).columns:
        le = LabelEncoder()
        train[c] = le.fit_transform(train[c].astype(str))
        known = set(le.classes_)
        mapped = test[c].astype(str).map(lambda v: v if v in known else le.classes_[0])
        test[c] = le.transform(mapped)
    return train, test


def impute_median(train: pd.DataFrame, test: pd.DataFrame):
    """Median imputation fitted on the training partition only."""
    med = train.median(numeric_only=True)
    return train.fillna(med), test.fillna(med)


def encode_single(X: pd.DataFrame) -> pd.DataFrame:
    """Encode and impute a single frame (full-sample explanation models)."""
    X = X.copy()
    for c in X.select_dtypes(include=["object"]).columns:
        X[c] = LabelEncoder().fit_transform(X[c].astype(str))
    return X.fillna(X.median(numeric_only=True))


def select_features(Xtr: pd.DataFrame, ytr: pd.Series,
                    n_repeats: int = R_IN_FOLD) -> list[str]:
    """Re-derive the predictor panel from a training partition (Section 2.4).

    Random-forest permutation importance on an internal 80/20 split, then the
    top-ranked predictors, with the three residence indicators force-retained
    irrespective of rank. Returns exactly N_SELECT features.
    """
    xi, xh, yi, yh = train_test_split(
        Xtr, ytr, test_size=0.20, random_state=SEED, stratify=ytr)
    rf = RandomForestClassifier(
        n_estimators=200, max_features="sqrt", class_weight="balanced",
        random_state=SEED, n_jobs=-1).fit(xi, yi)
    pi = permutation_importance(
        rf, xh, yh, n_repeats=n_repeats, random_state=SEED,
        n_jobs=-1, scoring="accuracy")
    rank = pd.Series(pi.importances_mean, index=Xtr.columns).sort_values(ascending=False)
    chosen = list(rank.index[:N_SELECT])
    non_residence = [c for c in chosen if c not in RESIDENCE]
    keep = [r for r in RESIDENCE if r in Xtr.columns]
    return non_residence[:N_SELECT - len(keep)] + keep


def sample_weights(y) -> np.ndarray:
    """Inverse-frequency class weights, w_c = N / (K n_c)  (Eq. 3)."""
    y = np.asarray(y)
    cw = compute_class_weight("balanced", classes=np.unique(y), y=y)
    table = dict(zip(np.unique(y), cw))
    return np.array([table[v] for v in y])


# -------------------------------------------------------------------- model
def make_xgb(params: dict | None = None) -> xgb.XGBClassifier:
    """Gradient-boosted classifier. Without params, the common configuration."""
    cfg = dict(COMMON_XGB)
    if params:
        cfg.update(params)
    return xgb.XGBClassifier(**cfg)


def fit_explanation_model(df: pd.DataFrame, panel: list[str],
                          params: dict | None = None):
    """Fit a full-sample model for attribution and return (model, X, y)."""
    X = encode_single(df[panel])
    y = target(df).values
    model = make_xgb(params).fit(X, y, sample_weight=sample_weights(y))
    return model, X, y


def shap_array(model, X: pd.DataFrame) -> np.ndarray:
    """Exact TreeSHAP attributions, shaped (n_households, n_features, n_classes)."""
    import shap
    values = shap.TreeExplainer(model).shap_values(X)
    return np.stack(values, axis=2) if isinstance(values, list) else values


# ----------------------------------------------------------------- bootstrap
def psu_blocks(df: pd.DataFrame):
    """Row indices grouped by primary sampling unit, and strata membership.

    Returns (rows_by_psu, psus_by_stratum, strata) for the stratified design
    bootstrap of Section 2.7.
    """
    psu = df["tspsu"].values
    rows_by_psu = {u: np.where(psu == u)[0] for u in pd.unique(psu)}
    psus_by_stratum = {
        st: pd.unique(sub["tspsu"].values)
        for st, sub in df.groupby("tsstrata")
    }
    return rows_by_psu, psus_by_stratum, sorted(psus_by_stratum)


def resample_psus(rng, rows_by_psu, psus_by_stratum, strata) -> np.ndarray:
    """One stratified design-bootstrap replicate: resample PSUs within strata."""
    picked = []
    for st in strata:
        pool = psus_by_stratum[st]
        picked.extend(pool[rng.integers(0, len(pool), len(pool))])
    return np.concatenate([rows_by_psu[u] for u in picked])


def percentile_ci(values, lo=2.5, hi=97.5):
    a, b = np.percentile(np.asarray(values, dtype=float), [lo, hi])
    return [float(a), float(b)]
