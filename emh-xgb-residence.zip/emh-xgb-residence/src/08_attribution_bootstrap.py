"""
Residence attribution with design-bootstrap intervals  ->  Tables 2, 3, 4, 5.

All attributions are computed under ONE common model configuration at every
window, so that they lie on a common scale (Section 2.7). Interval estimates
come from a stratified design bootstrap: in each replicate the primary
sampling units are resampled WITHIN strata, all households in the selected
units are retained, the model is REFITTED, and TreeSHAP is recomputed. This
admits both the clustering of the survey design and the variability of
re-estimating the model, which a household-level bootstrap of a single fitted
model omits -- the latter is narrower here by a factor of roughly forty-five.

Produces:
  Table 2  five most important predictors per window
  Table 3  residence attribution, raw and as a share of total attribution
  Table 4  signed per-class contributions for rural and non-metropolitan
  Table 5  signed contribution of census region to the very-low class
  the per-window figures behind Figure 1
  the rural-versus-urban comparison behind Figure 3 and Section 3.5

Expected: census region accounts for 1.03%, 1.14% and 1.08% of total
attribution across the three windows, with intervals 0.54-1.87%, 0.56-1.90%
and 0.46-1.86% -- overlapping, so no window difference is distinguishable. Of
the twenty-four signed contributions in Table 4, one excludes zero.

Usage:  python 08_attribution_bootstrap.py <DATA_DIR> <OUT_DIR> [N_REPLICATES]
Runtime: roughly 25 minutes per window at 200 replicates on 8 cores.
Checkpointed per replicate; re-running resumes.
"""
import sys, os, json, time, warnings
import numpy as np
import pandas as pd
warnings.filterwarnings("ignore")
import pipeline as P

DATA, OUT = sys.argv[1], sys.argv[2]
B = int(sys.argv[3]) if len(sys.argv) > 3 else 200
os.makedirs(OUT, exist_ok=True)
CKPT = os.path.join(OUT, "attribution_bootstrap.jsonl")


def summarise(df, panel):
    """All attribution summaries for one sample, under the common configuration."""
    model, X, y = P.fit_explanation_model(df, panel)
    if len(np.unique(y)) < 4:
        return None
    A = P.shap_array(model, X)
    cols = list(X.columns)
    per_feature = np.abs(A).mean(axis=(0, 2))
    total = float(per_feature.sum())
    out = {"total": total}

    # global importance, raw and normalised  (Table 3)
    for v in P.RESIDENCE:
        raw = float(per_feature[cols.index(v)])
        out[v] = raw
        out[v + "_share"] = raw / total

    # signed per-class contributions among carriers  (Table 4, Eq. 6)
    for name in ("rural", "nonmetro"):
        idx = cols.index(name)
        carriers = np.where(df[name].values == 1)[0]
        out[name + "_n"] = int(len(carriers))
        for ci, cls in enumerate(P.CLASSES):
            out[f"{name}_{cls}"] = (float(A[carriers, idx, ci].mean())
                                    if len(carriers) else None)

    # signed regional contribution to the very-low class  (Table 5)
    gi = cols.index("region")
    for code, region in P.REGIONS.items():
        members = np.where(df["region"].values == code)[0]
        out[f"region_VLFS_{region}"] = (float(A[members, gi, 3].mean())
                                        if len(members) else None)
        out[f"region_n_{region}"] = int(len(members))
    return out


def top_predictors(df, panel, k=8):
    model, X, _ = P.fit_explanation_model(df, panel)
    A = P.shap_array(model, X)
    series = pd.Series(np.abs(A).mean(axis=(0, 2)), index=list(X.columns))
    series = series.sort_values(ascending=False)
    ranks = {v: int(list(series.index).index(v)) + 1 for v in P.RESIDENCE}
    return ([(k_, round(float(v), 4)) for k_, v in series.head(k).items()],
            ranks, series)


def main():
    panel = P.load_panel(DATA)
    done = set()
    if os.path.exists(CKPT):
        for line in open(CKPT):
            if line.strip():
                r = json.loads(line)
                done.add((r["window"], r["b"]))
    t0 = time.time()
    fh = open(CKPT, "a")

    for window in ("H1", "H2", "H3"):
        df = P.load_window(DATA, window)
        rows_by_psu, psus_by_stratum, strata = P.psu_blocks(df)

        if (window, -1) not in done:                      # point estimate
            rec = summarise(df, panel)
            rec.update({"window": window, "b": -1, "n": int(len(df))})
            fh.write(json.dumps(rec) + "\n"); fh.flush()
            done.add((window, -1))
            print(f"{window} point: region share {rec['region_share']:.5f}", flush=True)

        rng = np.random.default_rng(P.SEED)
        for b in range(B):
            if (window, b) in done:                       # keep the stream aligned
                for st in strata:
                    rng.integers(0, len(psus_by_stratum[st]), len(psus_by_stratum[st]))
                continue
            idx = P.resample_psus(rng, rows_by_psu, psus_by_stratum, strata)
            rec = summarise(df.iloc[idx].reset_index(drop=True), panel)
            if rec is None:
                continue
            rec.update({"window": window, "b": b, "n": int(len(idx))})
            fh.write(json.dumps(rec) + "\n")
            if b % 50 == 0:
                fh.flush()
                print(f"  {window} replicate {b} ({time.time()-t0:.0f}s)", flush=True)
    fh.close()

    # ---- assemble the tables
    records = pd.DataFrame([json.loads(l) for l in open(CKPT) if l.strip()])
    keys = ([v + s for v in P.RESIDENCE for s in ("", "_share")]
            + [f"{n}_{c}" for n in ("rural", "nonmetro") for c in P.CLASSES]
            + [f"region_VLFS_{r}" for r in P.REGIONS.values()])
    tables = {}
    for window in ("H1", "H2", "H3"):
        sub = records[records.window == window]
        point = sub[sub.b == -1].iloc[0]
        boot = sub[sub.b >= 0]
        entry = {"n": int(point["n"]), "n_replicates": int(len(boot)),
                 "total_abs_shap": round(float(point["total"]), 4),
                 "rural_n": int(point["rural_n"]),
                 "nonmetro_n": int(point["nonmetro_n"])}
        for k in keys:
            col = boot[k].dropna()
            entry[k] = {"point": round(float(point[k]), 6),
                        "ci": [round(v, 6) for v in P.percentile_ci(col)],
                        "excludes_zero": bool(P.percentile_ci(col)[0] > 0
                                              or P.percentile_ci(col)[1] < 0)}
        top, ranks, series = top_predictors(P.load_window(DATA, window), panel)
        entry["top_predictors"] = top
        entry["residence_ranks"] = ranks
        tables[window] = entry

    # rural versus urban attribution within the six-month window (Section 3.5)
    df3 = P.load_window(DATA, "H3")
    model, X, _ = P.fit_explanation_model(df3, panel)
    A = P.shap_array(model, X)
    cols = list(X.columns)
    rural_mask = df3["rural"].values == 1
    groups = {}
    for name, mask in (("rural", rural_mask), ("urban", ~rural_mask)):
        series = pd.Series(np.abs(A[mask]).mean(axis=(0, 2)), index=cols)
        groups[name] = {"n": int(mask.sum()),
                        "attribution": {k: round(float(v), 4)
                                        for k, v in series.sort_values(ascending=False).items()}}
    tables["H3_rural_vs_urban"] = groups

    with open(os.path.join(OUT, "attribution_tables.json"), "w") as f:
        json.dump(tables, f, indent=2)
    print("\nwrote attribution_tables.json")
    for window in ("H1", "H2", "H3"):
        for v in P.RESIDENCE:
            e = tables[window][v + "_share"]
            print(f"  {window} {v:9s} share {e['point']*100:.2f}% "
                  f"[{e['ci'][0]*100:.2f}, {e['ci'][1]*100:.2f}]")


if __name__ == "__main__":
    main()
