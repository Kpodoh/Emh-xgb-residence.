"""
Survey design: weighting and clustering  ->  Table A4 and the design effects.

FAPS is released with a complex sample design -- a household analysis weight
(hhwgt), 25 strata (tsstrata) and 57 primary sampling units (tspsu). These are
excluded from the predictor set as artefacts of the sampling frame, but they
bear on interpretation in two ways (Section 2.1):

  (1) the analytic sample over-represents food insecurity, so weighted and
      unweighted compositions differ substantially (Table A4);
  (2) the residence indicators are heavily clustered within PSUs, giving large
      design effects and so a much smaller effective sample than 4,826.

Expected at H1: high food security 52.3% unweighted against 69.2% weighted;
rural 27.2% against 33.8%; non-metropolitan 8.8% against 13.5%. Design
effects approximately 37 (rural), 43 (non-metropolitan), 3 (very low FS).

Usage:  python 06_survey_design.py <DATA_DIR> <OUT_DIR>
"""
import sys, os, json
import numpy as np
import pandas as pd
import pipeline as P

DATA, OUT = sys.argv[1], sys.argv[2]
os.makedirs(OUT, exist_ok=True)
B = 2000


def main():
    out = {}
    for window in ("H1", "H2", "H3"):
        # Reseeded per window so each window's intervals are reproducible
        # independently of the order in which the windows are run.
        RNG = np.random.default_rng(P.SEED)
        df = P.load_window(DATA, window)
        w = df["hhwgt"].values.astype(float)
        psu = df["tspsu"].values
        n = len(df)
        res = {"n": int(n), "n_psu": int(pd.unique(psu).size),
               "n_strata": int(df["tsstrata"].nunique()),
               "weight_cv": round(float(w.std() / w.mean()), 3)}

        def shares(column, values):
            table = {}
            for v in values:
                mask = df[column].values == v
                table[str(v)] = {
                    "unweighted": round(float(mask.mean()), 4),
                    "weighted": round(float(w[mask].sum() / w.sum()), 4)}
            return table

        res["adltfscat"] = shares("adltfscat", [1, 2, 3, 4])
        res["rural"] = shares("rural", [0, 1])
        res["nonmetro"] = shares("nonmetro", [0, 1])
        res["region"] = shares("region", [1, 2, 3, 4])

        # design effects: variance under PSU-cluster resampling against
        # simple random resampling of households
        unique_psu = pd.unique(psu)
        rows_by_psu = {u: np.where(psu == u)[0] for u in unique_psu}
        n_psu = len(unique_psu)

        def srs(mask, RNG=RNG):
            return np.array([mask[RNG.integers(0, n, n)].mean() for _ in range(B)])

        def clustered(mask, RNG=RNG):
            draws = np.empty(B)
            for b in range(B):
                picked = unique_psu[RNG.integers(0, n_psu, n_psu)]
                idx = np.concatenate([rows_by_psu[u] for u in picked])
                draws[b] = mask[idx].mean()
            return draws

        effects = {}
        for name, mask in (("rural", df["rural"].values == 1),
                           ("nonmetro", df["nonmetro"].values == 1),
                           ("VLFS", df["adltfscat"].values == 4)):
            m = mask.astype(float)
            s, c = srs(m), clustered(m)
            effects[name] = {
                "p": round(float(m.mean()), 4),
                "se_srs": round(float(s.std()), 4),
                "se_cluster": round(float(c.std()), 4),
                "design_effect": round(float((c.std() / s.std()) ** 2), 2),
                "ci_srs": [round(v, 4) for v in P.percentile_ci(s)],
                "ci_cluster": [round(v, 4) for v in P.percentile_ci(c)]}
        res["design_effects"] = effects

        # how far the residence indicators are spread over the PSUs
        res["psu_coverage"] = {
            "rural": int(df[df.rural == 1]["tspsu"].nunique()),
            "nonmetro": int(df[df.nonmetro == 1]["tspsu"].nunique()),
            "total_psu": int(n_psu)}
        out[window] = res

        print(f"== {window}  n={n}  PSUs={res['n_psu']}  strata={res['n_strata']}")
        print("   class shares unweighted vs weighted:",
              {k: (v["unweighted"], v["weighted"]) for k, v in res["adltfscat"].items()})
        print("   rural    %.4f vs %.4f" % (res["rural"]["1"]["unweighted"],
                                            res["rural"]["1"]["weighted"]))
        print("   nonmetro %.4f vs %.4f" % (res["nonmetro"]["1"]["unweighted"],
                                            res["nonmetro"]["1"]["weighted"]))
        for k, v in effects.items():
            print(f"   design effect {k:9s} {v['design_effect']}")

    with open(os.path.join(OUT, "survey_design.json"), "w") as fh:
        json.dump(out, fh, indent=2)
    print("\nwrote survey_design.json")


if __name__ == "__main__":
    main()
