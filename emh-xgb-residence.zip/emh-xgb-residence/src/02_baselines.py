"""
Baseline-classifier comparison  ->  Table A5.

Random forest and multinomial logistic regression under the identical nested
protocol used for the gradient-boosted model in 01_nested_cv.py: the same
outer folds, the same in-fold panel re-derivation, an inner tuning loop and
the same inverse-frequency class weights. Answers whether the choice of
gradient boosting costs predictive accuracy (Section 2.6).

Expected macro F1 (SD): logistic regression leads at H1 (0.472) and H3
(0.458), gradient boosting at H2 (0.484); every pairwise difference is
smaller than the corresponding fold standard deviation.

Usage:  python 02_baselines.py <DATA_DIR> <OUT_DIR>
"""
import sys, os, json, time
import numpy as np
import pandas as pd
from sklearn.model_selection import StratifiedKFold
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import (accuracy_score, precision_score, recall_score,
                             f1_score, roc_auc_score)
import pipeline as P

DATA, OUT = sys.argv[1], sys.argv[2]
os.makedirs(OUT, exist_ok=True)
CKPT = os.path.join(OUT, "baselines.folds.jsonl")

RF_GRID = {"n_estimators": [200, 400], "max_depth": [None, 10, 20],
           "min_samples_leaf": [1, 3, 5], "max_features": ["sqrt", 0.3]}
LR_GRID = {"C": [0.01, 0.1, 1.0, 10.0]}
RF_DRAWS = 10


def build(kind, params):
    if kind == "RF":
        return RandomForestClassifier(random_state=P.SEED, n_jobs=-1,
                                      class_weight="balanced", **params)
    return LogisticRegression(max_iter=3000, solver="lbfgs",
                              class_weight="balanced", random_state=P.SEED, **params)


def scale(train, test):
    sc = StandardScaler().fit(train)
    return (pd.DataFrame(sc.transform(train), columns=train.columns),
            pd.DataFrame(sc.transform(test), columns=test.columns))


def tune(kind, X, y, rng):
    if kind == "LR":
        draws = [{"C": c} for c in LR_GRID["C"]]
    else:
        draws = [{k: RF_GRID[k][rng.integers(0, len(RF_GRID[k]))] for k in RF_GRID}
                 for _ in range(RF_DRAWS)]
    inner = StratifiedKFold(n_splits=3, shuffle=True, random_state=P.SEED)
    best_score, best_params = -1.0, None
    for params in draws:
        scores = []
        for tr, va in inner.split(X, y):
            xt, xv = X.iloc[tr], X.iloc[va]
            if kind == "LR":
                xt, xv = scale(xt, xv)
            model = build(kind, params).fit(xt, y.iloc[tr])
            scores.append(f1_score(y.iloc[va], model.predict(xv),
                                   average="macro", zero_division=0))
        if np.mean(scores) > best_score:
            best_score, best_params = float(np.mean(scores)), params
    return best_params


def main():
    done = {}
    if os.path.exists(CKPT):
        for line in open(CKPT):
            if line.strip():
                r = json.loads(line)
                done[(r["window"], r["learner"], r["fold"])] = r
    t0 = time.time()

    for window in ("H3", "H2", "H1"):          # smallest first
        df = P.load_window(DATA, window)
        X = df[P.predictor_pool(df)].reset_index(drop=True)
        y = P.target(df)
        outer = StratifiedKFold(n_splits=5, shuffle=True, random_state=P.SEED)
        for k, (tr, te) in enumerate(outer.split(X, y), 1):
            needed = [kd for kd in ("RF", "LR") if (window, kd, k) not in done]
            if not needed:
                continue
            Xtr, Xte = X.iloc[tr].copy(), X.iloc[te].copy()
            ytr, yte = y.iloc[tr].copy(), y.iloc[te].copy()
            Xtr, Xte = P.encode(Xtr, Xte)
            Xtr, Xte = P.impute_median(Xtr, Xte)
            feats = P.select_features(Xtr, ytr, n_repeats=P.R_IN_FOLD)
            Xtr, Xte = Xtr[feats], Xte[feats]
            rng = np.random.default_rng(P.SEED + k)

            for kind in needed:
                params = tune(kind, Xtr, ytr, rng)
                xt, xe = (scale(Xtr, Xte) if kind == "LR" else (Xtr, Xte))
                model = build(kind, params).fit(xt, ytr)
                pred, proba = model.predict(xe), model.predict_proba(xe)
                rec = {
                    "window": window, "learner": kind, "fold": k,
                    "n_test": int(len(yte)), "params": params,
                    "acc": accuracy_score(yte, pred),
                    "prec_w": precision_score(yte, pred, average="weighted", zero_division=0),
                    "rec_w": recall_score(yte, pred, average="weighted", zero_division=0),
                    "f1_w": f1_score(yte, pred, average="weighted", zero_division=0),
                    "f1_macro": f1_score(yte, pred, average="macro", zero_division=0),
                    "roc_auc": roc_auc_score(yte, proba, multi_class="ovr", average="macro"),
                }
                with open(CKPT, "a") as fh:
                    fh.write(json.dumps(rec, default=str) + "\n")
                done[(window, kind, k)] = rec
                print(f"  {window} {kind} fold {k}: macro F1 {rec['f1_macro']:.4f} "
                      f"({time.time()-t0:.0f}s)", flush=True)

    agg = {}
    for window in ("H1", "H2", "H3"):
        agg[window] = {}
        for kind in ("RF", "LR"):
            rows = [done[(window, kind, k)] for k in range(1, 6)
                    if (window, kind, k) in done]
            if len(rows) < 5:
                agg[window][kind] = {"incomplete": len(rows)}
                continue
            agg[window][kind] = {
                m: {"mean": round(float(np.mean([r[m] for r in rows])), 4),
                    "std": round(float(np.std([r[m] for r in rows])), 4)}
                for m in ("acc", "prec_w", "rec_w", "f1_w", "f1_macro", "roc_auc")}
    with open(os.path.join(OUT, "baselines.json"), "w") as fh:
        json.dump(agg, fh, indent=2)
    print(json.dumps(agg, indent=2))


if __name__ == "__main__":
    main()
