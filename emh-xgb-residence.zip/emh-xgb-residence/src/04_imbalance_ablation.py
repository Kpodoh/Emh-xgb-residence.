"""
Class-imbalance strategy ablation and per-class metrics  ->  Tables A1 and A2.

Five-fold stratified cross-validation on the locked 59-predictor panel, with
resampling, weighting and threshold tuning all fitted inside each training
fold. Four strategies are compared: unweighted, inverse-frequency weights,
SMOTE-ENN, and weights plus post-hoc decision-threshold optimisation.

NOTE ON CONFIGURATION. Tables A1-A3 as published use the per-window
hyperparameters selected by the original tuning (configuration A at H1 and H2,
configuration B at H3; see pipeline.CONFIGS). Tables 2-5 and A7 instead use one
common configuration at every window, because attribution magnitudes are not
comparable across differently tuned models (Section 2.7). Macro F1 is a
scale-free quantity, so the strategy ranking in Table A1 is not affected by
this choice, but pass --config common to reproduce these tables under the
common configuration instead.

Expected (macro F1 at H1/H2/H3): unweighted 0.459/0.457/0.419;
weighted 0.479/0.484/0.440; SMOTE-ENN 0.439/0.443/0.379;
weighted + thresholds 0.480/0.473/0.465.

Usage:  python 04_imbalance_ablation.py <DATA_DIR> <OUT_DIR> [--config common]
"""
import sys, os, json, warnings
import numpy as np
warnings.filterwarnings("ignore")
from sklearn.model_selection import StratifiedKFold
from sklearn.metrics import (f1_score, accuracy_score,
                             precision_recall_fscore_support)
from scipy.optimize import minimize
from imblearn.combine import SMOTEENN
import pipeline as P

DATA, OUT = sys.argv[1], sys.argv[2]
USE_COMMON = "--config" in sys.argv and "common" in sys.argv
os.makedirs(OUT, exist_ok=True)
PUBLISHED = {"H1": P.CONFIGS["A"], "H2": P.CONFIGS["A"], "H3": P.CONFIGS["B"]}
VARIANTS = ["base", "weighted", "smoteenn", "weighted_threshold"]


def optimise_thresholds(y_true, proba):
    """Nelder-Mead search for per-class multipliers maximising macro F1."""
    def loss(w):
        return -f1_score(y_true, np.argmax(proba * w, axis=1),
                         average="macro", zero_division=0)
    result = minimize(loss, [1.0] * 4, method="Nelder-Mead",
                      options={"maxiter": 1000})
    return result.x


def run(window):
    params = None if USE_COMMON else PUBLISHED[window]
    df = P.load_window(DATA, window)
    panel = P.load_panel(DATA)
    X = P.encode_single(df[panel])
    y = P.target(df)
    skf = StratifiedKFold(n_splits=5, shuffle=True, random_state=P.SEED)

    ablation = {v: {"macro_f1": [], "weighted_f1": [], "accuracy": []}
                for v in VARIANTS}
    per_class = {c: {"precision": [], "recall": [], "f1": []} for c in P.CLASSES}

    for tr, va in skf.split(X, y):
        Xtr, Xva = X.iloc[tr], X.iloc[va]
        ytr, yva = y.iloc[tr], y.iloc[va]

        for variant in VARIANTS:
            if variant == "base":
                model = P.make_xgb(params).fit(Xtr, ytr)
            elif variant == "smoteenn":
                Xr, yr = SMOTEENN(random_state=P.SEED).fit_resample(Xtr, ytr)
                model = P.make_xgb(params).fit(Xr, yr)
            else:
                model = P.make_xgb(params).fit(
                    Xtr, ytr, sample_weight=P.sample_weights(ytr))

            proba = model.predict_proba(Xva)
            if variant == "weighted_threshold":
                train_proba = model.predict_proba(Xtr)
                mult = optimise_thresholds(ytr.values, train_proba)
                pred = np.argmax(proba * mult, axis=1)
            else:
                pred = np.argmax(proba, axis=1)

            ablation[variant]["macro_f1"].append(
                f1_score(yva, pred, average="macro", zero_division=0))
            ablation[variant]["weighted_f1"].append(
                f1_score(yva, pred, average="weighted", zero_division=0))
            ablation[variant]["accuracy"].append(accuracy_score(yva, pred))

            if variant == "weighted":      # per-class breakdown, Table A2
                prec, rec, f1v, _ = precision_recall_fscore_support(
                    yva, pred, labels=[0, 1, 2, 3], zero_division=0)
                for i, c in enumerate(P.CLASSES):
                    per_class[c]["precision"].append(prec[i])
                    per_class[c]["recall"].append(rec[i])
                    per_class[c]["f1"].append(f1v[i])

    def summarise(d):
        return {k: {"mean": round(float(np.mean(v)), 4),
                    "std": round(float(np.std(v)), 4)} for k, v in d.items()}

    out = {"window": window,
           "configuration": "common" if USE_COMMON else "published per-window",
           "ablation": {v: summarise(ablation[v]) for v in VARIANTS},
           "per_class": {c: summarise(per_class[c]) for c in P.CLASSES}}
    tag = "common" if USE_COMMON else "published"
    with open(os.path.join(OUT, f"ablation_{window}_{tag}.json"), "w") as fh:
        json.dump(out, fh, indent=2)
    print(f"== {window} ({out['configuration']})")
    for v in VARIANTS:
        print(f"   {v:20s} macro F1 {out['ablation'][v]['macro_f1']['mean']:.4f} "
              f"({out['ablation'][v]['macro_f1']['std']:.3f})")


if __name__ == "__main__":
    for w in ("H1", "H2", "H3"):
        run(w)
