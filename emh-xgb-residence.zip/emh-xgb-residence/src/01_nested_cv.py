"""
Nested cross-validation of the gradient-boosted model  ->  Table 1, Figure 2 (ROC).

Outer five-fold stratified loop. Within each outer training partition, and
without reference to the held-out fold: encoding and median imputation are
fitted, the predictor panel is re-derived, class weights are recomputed, and
an inner three-fold loop selects hyperparameters over twenty random draws.
Out-of-fold predicted probabilities are saved for the ROC curves.

Expected (mean across five outer folds, SD in parentheses):
    H1  accuracy 0.558 (0.022)  macro F1 0.470 (0.024)  ROC-AUC 0.788 (0.012)
    H2  accuracy 0.579 (0.017)  macro F1 0.484 (0.018)  ROC-AUC 0.795 (0.008)
    H3  accuracy 0.553 (0.022)  macro F1 0.443 (0.024)  ROC-AUC 0.768 (0.025)

Usage:  python 01_nested_cv.py <DATA_DIR> <OUT_DIR>
Runtime: roughly 10-25 minutes per window on 8 cores. Each completed fold is
appended to a checkpoint file, so an interrupted run resumes where it stopped.
"""
import sys, os, json, time
import numpy as np
from sklearn.model_selection import StratifiedKFold
from sklearn.metrics import (accuracy_score, precision_score, recall_score,
                             f1_score, roc_auc_score)
import pipeline as P

DATA, OUT = sys.argv[1], sys.argv[2]
os.makedirs(OUT, exist_ok=True)


def tune_inner(X, y, rng):
    """Inner three-fold random search over the grid, maximising macro F1."""
    draws = [{k: rng.choice(v) for k, v in P.GRID.items()}
             for _ in range(P.N_ITER_INNER)]
    inner = StratifiedKFold(n_splits=3, shuffle=True, random_state=P.SEED)
    best_score, best_params = -1.0, None
    for params in draws:
        params = {k: (int(v) if k in ("n_estimators", "max_depth") else float(v))
                  for k, v in params.items()}
        scores = []
        for tr, va in inner.split(X, y):
            model = P.make_xgb(params).fit(
                X.iloc[tr], y.iloc[tr], sample_weight=P.sample_weights(y.iloc[tr]))
            scores.append(f1_score(y.iloc[va], model.predict(X.iloc[va]),
                                   average="macro", zero_division=0))
        if np.mean(scores) > best_score:
            best_score, best_params = float(np.mean(scores)), params
    return best_params


def run(window):
    ckpt = os.path.join(OUT, f"nested_{window}.folds.jsonl")
    done = {}
    if os.path.exists(ckpt):
        for line in open(ckpt):
            if line.strip():
                rec = json.loads(line)
                done[rec["fold"]] = rec

    df = P.load_window(DATA, window)
    X = df[P.predictor_pool(df)].reset_index(drop=True)
    y = P.target(df)
    outer = StratifiedKFold(n_splits=5, shuffle=True, random_state=P.SEED)
    t0 = time.time()

    for k, (tr, te) in enumerate(outer.split(X, y), 1):
        if k in done:
            continue
        Xtr, Xte = X.iloc[tr].copy(), X.iloc[te].copy()
        ytr, yte = y.iloc[tr].copy(), y.iloc[te].copy()
        Xtr, Xte = P.encode(Xtr, Xte)
        Xtr, Xte = P.impute_median(Xtr, Xte)
        feats = P.select_features(Xtr, ytr, n_repeats=P.R_IN_FOLD)
        rng = np.random.default_rng(P.SEED + k)
        params = tune_inner(Xtr[feats], ytr, rng)

        model = P.make_xgb(params).fit(
            Xtr[feats], ytr, sample_weight=P.sample_weights(ytr))
        pred = model.predict(Xte[feats])
        proba = model.predict_proba(Xte[feats])

        # out-of-fold predictions, kept for the ROC curves
        np.save(os.path.join(OUT, f"oof_{window}_probs_fold{k}.npy"), proba)
        np.save(os.path.join(OUT, f"oof_{window}_ytrue_fold{k}.npy"), yte.values)

        rec = {
            "fold": k, "n_test": int(len(yte)), "params": params,
            "acc": accuracy_score(yte, pred),
            "prec_w": precision_score(yte, pred, average="weighted", zero_division=0),
            "rec_w": recall_score(yte, pred, average="weighted", zero_division=0),
            "f1_w": f1_score(yte, pred, average="weighted", zero_division=0),
            "f1_macro": f1_score(yte, pred, average="macro", zero_division=0),
            "roc_auc": roc_auc_score(yte, proba, multi_class="ovr", average="macro"),
            "residence_retained": [r for r in P.RESIDENCE if r in feats],
        }
        with open(ckpt, "a") as fh:
            fh.write(json.dumps(rec, default=str) + "\n")
        done[k] = rec
        print(f"  {window} fold {k}: macro F1 {rec['f1_macro']:.4f} "
              f"AUC {rec['roc_auc']:.4f}  ({time.time()-t0:.0f}s)", flush=True)

    folds = [done[k] for k in sorted(done)]
    agg = {m: {"mean": round(float(np.mean([f[m] for f in folds])), 4),
               "std": round(float(np.std([f[m] for f in folds])), 4)}
           for m in ("acc", "prec_w", "rec_w", "f1_w", "f1_macro", "roc_auc")}
    out = {"window": window, "n_total": int(len(y)), "outer_folds": 5,
           "inner_folds": 3, "n_iter_inner": P.N_ITER_INNER, "seed": P.SEED,
           "aggregate": agg, "folds": folds}
    with open(os.path.join(OUT, f"nested_{window}.json"), "w") as fh:
        json.dump(out, fh, indent=2, default=str)
    print(f"{window}: macro F1 {agg['f1_macro']['mean']} ({agg['f1_macro']['std']}), "
          f"ROC-AUC {agg['roc_auc']['mean']} ({agg['roc_auc']['std']})")


if __name__ == "__main__":
    for w in ("H1", "H2", "H3"):
        run(w)
