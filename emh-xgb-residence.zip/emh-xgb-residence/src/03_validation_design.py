"""
Design-respecting and temporal validation  ->  Table A6.

Stratified folds balance the outcome classes but ignore the survey design, so
households from the same primary sampling unit may fall on both sides of a
split. Because the residence indicators are heavily clustered within those
units, that is a route by which geographic information crosses the partition.
Two further validations (Section 2.6):

  (1) stratified GROUP folds, placing no PSU in both train and test;
  (2) temporal validation, training on early enrolment months and testing on
      later months withheld entirely from training.

Expected: under group folds macro F1 is 0.466, 0.461, 0.453 at H1/H2/H3 --
monotonically declining, with the three-month advantage of Table 1 gone.
Temporal: 0.450 (train months 1-6, test 7-12) and 0.441 (train 1-9, test 10-12).

Usage:  python 03_validation_design.py <DATA_DIR> <OUT_DIR>
"""
import sys, os, json, time
import numpy as np
from sklearn.model_selection import StratifiedGroupKFold, StratifiedKFold
from sklearn.metrics import accuracy_score, f1_score, roc_auc_score
import pipeline as P

DATA, OUT = sys.argv[1], sys.argv[2]
os.makedirs(OUT, exist_ok=True)
CKPT = os.path.join(OUT, "validation_design.jsonl")
N_ITER = 8          # reduced inner draws; this is a robustness check, not Table 1

TEMPORAL = {
    "train_m1-6_test_m7-12":  ({1, 4, 5, 6},             {7, 8, 9, 10, 11, 12}),
    "train_m1-9_test_m10-12": ({1, 4, 5, 6, 7, 8, 9},    {10, 11, 12}),
}


def tune(X, y, rng):
    draws = [{k: (int(rng.choice(v)) if k in ("n_estimators", "max_depth")
                  else float(rng.choice(v))) for k, v in P.GRID.items()}
             for _ in range(N_ITER)]
    inner = StratifiedKFold(n_splits=3, shuffle=True, random_state=P.SEED)
    best, best_params = -1.0, None
    for params in draws:
        scores = []
        for tr, va in inner.split(X, y):
            m = P.make_xgb(params).fit(X.iloc[tr], y.iloc[tr],
                                       sample_weight=P.sample_weights(y.iloc[tr]))
            scores.append(f1_score(y.iloc[va], m.predict(X.iloc[va]),
                                   average="macro", zero_division=0))
        if np.mean(scores) > best:
            best, best_params = float(np.mean(scores)), params
    return best_params


def evaluate(Xtr, ytr, Xte, yte, rng):
    Xtr, Xte = P.encode(Xtr, Xte)
    Xtr, Xte = P.impute_median(Xtr, Xte)
    feats = P.select_features(Xtr, ytr, n_repeats=P.R_IN_FOLD)
    params = tune(Xtr[feats], ytr, rng)
    model = P.make_xgb(params).fit(Xtr[feats], ytr,
                                   sample_weight=P.sample_weights(ytr))
    pred, proba = model.predict(Xte[feats]), model.predict_proba(Xte[feats])
    return {"acc": accuracy_score(yte, pred),
            "f1_macro": f1_score(yte, pred, average="macro", zero_division=0),
            "roc_auc": roc_auc_score(yte, proba, multi_class="ovr", average="macro"),
            "n_test": int(len(yte)), "params": params}


def main():
    done = {}
    if os.path.exists(CKPT):
        for line in open(CKPT):
            if line.strip():
                r = json.loads(line)
                done[r["key"]] = r
    t0 = time.time()

    def emit(key, rec):
        rec["key"] = key
        with open(CKPT, "a") as fh:
            fh.write(json.dumps(rec, default=str) + "\n")
        done[key] = rec
        print(f"  {key}: macro F1 {rec['f1_macro']:.4f} AUC {rec['roc_auc']:.4f} "
              f"({time.time()-t0:.0f}s)", flush=True)

    print("(1) stratified group five-fold, clustered by primary sampling unit")
    for window in ("H1", "H2", "H3"):
        df = P.load_window(DATA, window)
        X = df[P.predictor_pool(df)]
        y = P.target(df)
        groups = df["tspsu"].values
        splitter = StratifiedGroupKFold(n_splits=5, shuffle=True, random_state=P.SEED)
        for k, (tr, te) in enumerate(splitter.split(X, y, groups), 1):
            key = f"psu_{window}_fold{k}"
            if key in done:
                continue
            emit(key, evaluate(X.iloc[tr].copy(), y.iloc[tr].copy(),
                               X.iloc[te].copy(), y.iloc[te].copy(),
                               np.random.default_rng(P.SEED + k)))

    print("(2) temporal enrolment-month validation")
    import pandas as pd
    full = pd.read_csv(os.path.join(DATA, "faps_final.csv"), low_memory=False)
    pool = P.predictor_pool(full)
    for key, (train_months, test_months) in TEMPORAL.items():
        if key in done:
            continue
        tr = full[full["startmon"].isin(train_months)].reset_index(drop=True)
        te = full[full["startmon"].isin(test_months)].reset_index(drop=True)
        emit(key, evaluate(tr[pool].copy(), P.target(tr),
                           te[pool].copy(), P.target(te),
                           np.random.default_rng(P.SEED)))

    agg = {}
    for window in ("H1", "H2", "H3"):
        rows = [done[f"psu_{window}_fold{k}"] for k in range(1, 6)
                if f"psu_{window}_fold{k}" in done]
        if len(rows) == 5:
            agg[f"psu_{window}"] = {
                m: {"mean": round(float(np.mean([r[m] for r in rows])), 4),
                    "std": round(float(np.std([r[m] for r in rows])), 4)}
                for m in ("acc", "f1_macro", "roc_auc")}
    for key in TEMPORAL:
        if key in done:
            agg[key] = {m: round(float(done[key][m]), 4)
                        for m in ("acc", "f1_macro", "roc_auc")}
    with open(os.path.join(OUT, "validation_design.json"), "w") as fh:
        json.dump(agg, fh, indent=2)
    print(json.dumps(agg, indent=2))


if __name__ == "__main__":
    main()
