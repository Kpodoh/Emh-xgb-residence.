"""
Equal-sample-size control  ->  Table A3.

The three windows are nested and differ substantially in size, so any
difference between them confounds the window with statistical power. All three
are reduced to n = 1,345 (the size of the six-month window) and re-evaluated
over twenty replicates: H1 and H2 by stratified subsampling, H3 -- already at
that size -- over twenty cross-validation seeds, so that only the data differ.

Expected macro F1: 0.451 (H1), 0.460 (H2), 0.458 (H3). At equal size the three
windows perform comparably, so most of the six-month deficit in Table 1 is
attributable to sample size rather than to the window.

See the configuration note in 04_imbalance_ablation.py; the same applies here.

Usage:  python 05_equal_n_control.py <DATA_DIR> <OUT_DIR> [--config common]
"""
import sys, os, json, warnings
import numpy as np
warnings.filterwarnings("ignore")
from sklearn.model_selection import StratifiedKFold, StratifiedShuffleSplit
from sklearn.metrics import f1_score
import pipeline as P

DATA, OUT = sys.argv[1], sys.argv[2]
USE_COMMON = "--config" in sys.argv and "common" in sys.argv
os.makedirs(OUT, exist_ok=True)
TARGET_N = 1345
N_REPS = 20
PUBLISHED = {"H1": P.CONFIGS["A"], "H2": P.CONFIGS["A"], "H3": P.CONFIGS["B"]}


def cv_macro_f1(X, y, params, cv_seed):
    skf = StratifiedKFold(n_splits=5, shuffle=True, random_state=cv_seed)
    scores = []
    for tr, va in skf.split(X, y):
        model = P.make_xgb(params).fit(
            X.iloc[tr], y.iloc[tr], sample_weight=P.sample_weights(y.iloc[tr]))
        scores.append(f1_score(y.iloc[va], model.predict(X.iloc[va]),
                               average="macro", zero_division=0))
    return float(np.mean(scores))


def main():
    panel = P.load_panel(DATA)
    out = {}
    for window in ("H1", "H2", "H3"):
        params = None if USE_COMMON else PUBLISHED[window]
        df = P.load_window(DATA, window)
        X = P.encode_single(df[panel])
        y = P.target(df)
        scores = []
        if len(X) > TARGET_N:
            splitter = StratifiedShuffleSplit(
                n_splits=N_REPS, train_size=TARGET_N, random_state=P.SEED)
            for rep, (idx, _) in enumerate(splitter.split(X, y)):
                scores.append(cv_macro_f1(X.iloc[idx].reset_index(drop=True),
                                          y.iloc[idx].reset_index(drop=True),
                                          params, P.SEED))
        else:
            for rep in range(N_REPS):
                scores.append(cv_macro_f1(X, y, params, P.SEED + rep))
        out[window] = {"n": int(min(len(X), TARGET_N)), "n_reps": N_REPS,
                       "macro_f1_mean": round(float(np.mean(scores)), 4),
                       "macro_f1_std": round(float(np.std(scores)), 4),
                       "min": round(float(np.min(scores)), 4),
                       "max": round(float(np.max(scores)), 4)}
        print(f"   {window}: macro F1 {out[window]['macro_f1_mean']:.4f} "
              f"({out[window]['macro_f1_std']:.3f})  "
              f"range {out[window]['min']:.3f}-{out[window]['max']:.3f}")
    tag = "common" if USE_COMMON else "published"
    with open(os.path.join(OUT, f"equal_n_control_{tag}.json"), "w") as fh:
        json.dump(out, fh, indent=2)


if __name__ == "__main__":
    main()
