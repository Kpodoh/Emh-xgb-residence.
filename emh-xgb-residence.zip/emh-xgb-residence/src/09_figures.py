"""
Figures  ->  the three figures in the manuscript.

  roc_curves.pdf            one-versus-rest ROC curves per window (printed as
                            Figure 1, after Table 1); needs 01_nested_cv.py
  residence_attribution.pdf residence attribution share by window with design-
                            bootstrap intervals (Figure 2); needs 08
  rural_vs_urban.pdf        rural against urban attribution, six-month window
                            (Figure 3); needs 08

Usage:  python 09_figures.py <OUT_DIR> <FIG_DIR>
"""
import sys, os, json
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from sklearn.metrics import roc_curve, auc
import pipeline as P

OUT, FIGS = sys.argv[1], sys.argv[2]
os.makedirs(FIGS, exist_ok=True)

WINDOWS = [("H1", "H1 (1 mo)", "#0072B2", "o"),
           ("H2", "H2 (3 mo)", "#D57C00", "s"),
           ("H3", "H3 (6 mo)", "#96468C", "^")]
CLASS_LABELS = ["High (FS)", "Marginal (MFS)", "Low (LFS)", "Very low (VLFS)"]
CLASS_COLOURS = ["#0072B2", "#D57C00", "#96468C", "#007A3D"]

# Expanded labels for the predictor codes that appear in the figures.
LABELS = {
    "fincondition": "Financial condition",
    "pctpovguidehh_r": "Income relative to\npoverty guideline",
    "healthycost": "Cost of a healthy diet", "liqassets": "Liquid assets",
    "inchhavg_r": "Average household income", "incfamavg_r": "Average family income",
    "expelectric_r": "Electricity expenditure",
    "billsontimefreq": "Bills paid on time (frequency)",
    "exprentmrtg_r": "Rent or mortgage expenditure",
    "largeexp": "Large unexpected expenditure",
    "payaboveminfreq": "Paying above the minimum\n(frequency)",
    "housingown": "Home ownership", "anytobacco": "Any tobacco use",
    "altstoreplaceid": "Alternate store identifier",
    "primstoreplaceid": "Primary store identifier",
    "exprx_r": "Prescription expenditure",
    "region": "Census region", "rural": "Rural residence",
    "nonmetro": "Non-metropolitan residence",
}
def label(key):
    return LABELS.get(key, key.replace("_", " "))


def tidy(ax):
    ax.grid(ls=":", lw=0.6, alpha=0.6)
    ax.set_axisbelow(True)
    for side in ("top", "right"):
        ax.spines[side].set_visible(False)


def roc_figure():
    fig, axes = plt.subplots(1, 3, figsize=(11.6, 4.0), sharey=True)
    for ax, (w, title, _, _) in zip(axes, WINDOWS):
        probs = np.concatenate([np.load(os.path.join(OUT, f"oof_{w}_probs_fold{k}.npy"))
                                for k in range(1, 6)])
        truth = np.concatenate([np.load(os.path.join(OUT, f"oof_{w}_ytrue_fold{k}.npy"))
                                for k in range(1, 6)])
        for c in range(4):
            fpr, tpr, _ = roc_curve((truth == c).astype(int), probs[:, c])
            ax.plot(fpr, tpr, color=CLASS_COLOURS[c], lw=1.6,
                    label=f"{CLASS_LABELS[c]} — AUC {auc(fpr, tpr):.3f}")
        ax.plot([0, 1], [0, 1], ls="--", lw=0.9, color="#999999")
        ax.set_title(f"{title}, $N={len(truth):,}$", fontsize=10)
        ax.set_xlabel("False positive rate")
        ax.set_xlim(0, 1); ax.set_ylim(0, 1)
        ax.legend(frameon=False, fontsize=7.4, loc="lower right")
        tidy(ax)
    axes[0].set_ylabel("True positive rate")
    fig.tight_layout()
    fig.savefig(os.path.join(FIGS, "roc_curves.pdf"), dpi=300)
    print("wrote roc_curves.pdf")


def attribution_figure(tables):
    indicators = [("region", "Census region"), ("rural", "Rural residence"),
                  ("nonmetro", "Non-metropolitan residence")]
    fig, ax = plt.subplots(figsize=(7.2, 4.3))
    for gi, (key, name) in enumerate(indicators):
        for wi, (w, wname, colour, marker) in enumerate(WINDOWS):
            entry = tables[w][key + "_share"]
            point = entry["point"] * 100
            lo, hi = entry["ci"][0] * 100, entry["ci"][1] * 100
            ax.errorbar(gi + (wi - 1) * 0.22, point,
                        yerr=[[point - lo], [hi - point]], fmt=marker,
                        color=colour, capsize=4, markersize=7, elinewidth=1.4,
                        label=wname if gi == 0 else None)
    ax.set_yscale("log")
    ax.set_xticks(range(len(indicators)))
    ax.set_xticklabels([n for _, n in indicators])
    ax.set_xlabel("Residence indicator")
    ax.set_ylabel("Share of total attribution (%, log scale)")
    ax.legend(frameon=False, loc="upper right", title="Enrolment window")
    tidy(ax)
    fig.tight_layout()
    fig.savefig(os.path.join(FIGS, "residence_attribution.pdf"), dpi=300)
    print("wrote residence_attribution.pdf")


def rural_urban_figure(tables):
    groups = tables["H3_rural_vs_urban"]
    rural = groups["rural"]["attribution"]
    urban = groups["urban"]["attribution"]
    keys = sorted(set(rural) & set(urban),
                  key=lambda k: -(rural[k] + urban[k]))[:15]
    y = np.arange(len(keys))[::-1]
    fig, ax = plt.subplots(figsize=(7.6, 6.4))
    ax.barh(y + 0.2, [rural[k] for k in keys], height=0.38, color="#0072B2",
            label=f"Rural (n={groups['rural']['n']})")
    ax.barh(y - 0.2, [urban[k] for k in keys], height=0.38, color="#B0B0B0",
            label=f"Urban (n={groups['urban']['n']})")
    ax.set_yticks(y)
    ax.set_yticklabels([label(k) for k in keys], fontsize=8.5)
    ax.set_xlabel("Mean |SHAP| (margin units), averaged across the four classes")
    ax.legend(frameon=False, loc="lower right")
    tidy(ax)
    fig.tight_layout()
    fig.savefig(os.path.join(FIGS, "rural_vs_urban.pdf"), dpi=300)
    print("wrote rural_vs_urban.pdf")


if __name__ == "__main__":
    tables_path = os.path.join(OUT, "attribution_tables.json")
    if os.path.exists(tables_path):
        tables = json.load(open(tables_path))
        attribution_figure(tables)
        rural_urban_figure(tables)
    else:
        print("attribution_tables.json not found; run 08 first")
    if os.path.exists(os.path.join(OUT, "oof_H1_probs_fold1.npy")):
        roc_figure()
    else:
        print("out-of-fold predictions not found; run 01 first")
