"""
Configuration cross-test and seasonal-composition check  ->  Table A7.

This is the evidence for the paper's methodological argument (Section 4).

Panel A crosses each enrolment window with both hyperparameter configurations.
If attribution magnitude were a property of the window, it would vary across
rows within a configuration; if it is a property of the model, it would vary
across configurations within a window. It does the latter: applying the
six-month configuration to the full one-month sample reduces census-region
attribution from 0.0246 to 0.0059, reproducing an apparent collapse with no
change of window at all, while applying the one-month configuration to the
six-month sample yields the largest attribution of the nine cells (0.0322).

Panel B computes attributions on three DISJOINT enrolment blocks of comparable
size under one configuration, to establish that seasonal composition of
enrolment does not account for differences between the nested windows: census
region is 0.0322, 0.0319 and 0.0299, a spread under eight per cent.

Usage:  python 07_config_crosstest.py <DATA_DIR> <OUT_DIR>
Runtime: a few minutes.
"""
import sys, os, json, warnings
import numpy as np
import pandas as pd
warnings.filterwarnings("ignore")
import pipeline as P

DATA, OUT = sys.argv[1], sys.argv[2]
os.makedirs(OUT, exist_ok=True)


def attribution(df, panel, params):
    model, X, _ = P.fit_explanation_model(df, panel, params)
    A = P.shap_array(model, X)
    per_feature = np.abs(A).mean(axis=(0, 2))
    total = float(per_feature.sum())
    cols = list(X.columns)
    row = {"n": int(len(df)), "total_abs_shap": round(total, 4)}
    for v in P.RESIDENCE:
        raw = float(per_feature[cols.index(v)])
        row[v] = round(raw, 4)
        row[v + "_share"] = round(raw / total, 5)
    return row


def main():
    panel = P.load_panel(DATA)
    full = pd.read_csv(os.path.join(DATA, "faps_final.csv"), low_memory=False)
    out = {"panel_A_window_by_configuration": [], "panel_B_disjoint_blocks": []}

    print("Panel A: window x configuration")
    for window in ("H1", "H2", "H3"):
        df = P.load_window(DATA, window)
        for name, params in P.CONFIGS.items():
            row = attribution(df, panel, params)
            row.update({"sample": window, "configuration": name})
            out["panel_A_window_by_configuration"].append(row)
            print(f"   {window} config {name}: region {row['region']:.4f} "
                  f"rural {row['rural']:.4f} nonmetro {row['nonmetro']:.4f} "
                  f"| total {row['total_abs_shap']:.4f}")

    print("Panel B: disjoint enrolment blocks, common configuration")
    for name, months in P.BLOCKS.items():
        df = full[full["startmon"].isin(months)].reset_index(drop=True)
        row = attribution(df, panel, P.CONFIGS["A"])
        row.update({"block": name, "configuration": "A"})
        out["panel_B_disjoint_blocks"].append(row)
        print(f"   {name:8s} n={row['n']:5d}: region {row['region']:.4f} "
              f"rural {row['rural']:.4f} nonmetro {row['nonmetro']:.4f} "
              f"| total {row['total_abs_shap']:.4f}")

    with open(os.path.join(OUT, "config_crosstest.json"), "w") as fh:
        json.dump(out, fh, indent=2)
    print("\nwrote config_crosstest.json")


if __name__ == "__main__":
    main()
