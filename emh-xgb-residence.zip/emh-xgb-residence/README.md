# Horizon-Specific Explainability in Household Food Security Prediction

Analysis code for the manuscript *Horizon-Specific Explainability in Household
Food Security Prediction: Evidence from a Gradient Boosting Model*
(Edoh, Mulwa and Akpalu).

Every table and figure in the manuscript is produced by one of the nine
scripts in `src/`. The mapping is given below, together with the values each
script should return, so that a reader can verify reproduction without
re-reading the paper.

---

## 1. Data

The analysis uses the USDA Food Acquisition and Purchase Survey (FAPS)
public-use files, available from the USDA Economic Research Service. FAPS is
not redistributed here.

Two files are expected in the data directory:

| File | Contents |
|:--|:--|
| `faps_final.csv` | 4,826 households, 171 columns: the cleaned analytic file, including the outcome `adltfscat`, the enrolment month `startmon`, and the survey design fields `hhwgt`, `tsstrata`, `tspsu`, `hhnum` |
| `faps_selected_features_59.csv` | the locked 59-predictor panel, with columns `Rank`, `Variable`, `Mean_PI`, `Domain` |

The three nested enrolment windows are derived from `faps_final.csv` by
filtering on `startmon`; no separate per-window files are needed.

Enrolment months present in the data are {1, 4, 5, 6, 7, 8, 9, 10, 11, 12};
months 2 and 3 contain no households. The windows are therefore:

| Window | Enrolment months | N |
|:--|:--|--:|
| H1 (1 mo) | all | 4,826 |
| H2 (3 mo) | 1–9 | 3,518 |
| H3 (6 mo) | 1–6 | 1,345 |

---

## 2. Installation and use

```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt

./run_all.sh /path/to/faps_data ./results ./figures
```

Or run a single step:

```bash
cd src
python 07_config_crosstest.py /path/to/faps_data ../results
```

Scripts 01, 02, 03 and 08 write a checkpoint after every fold or bootstrap
replicate, so an interrupted run resumes where it stopped rather than
restarting. Total runtime is several hours; script 08 is the longest at
roughly 25 minutes per window.

**Version pinning matters.** `xgboost` and `shap` can change attribution
magnitudes between releases. `requirements.txt` pins the versions used for the
reported results; later versions reproduce the qualitative findings but may
shift attribution values in the fourth decimal place.

---

## 3. What each script produces

| Script | Produces | Manuscript |
|:--|:--|:--|
| `pipeline.py` | shared preprocessing, feature selection, weighting, model construction and bootstrap helpers — not run directly | §2.4–2.7 |
| `01_nested_cv.py` | nested CV performance; out-of-fold probabilities | Table 1, ROC figure |
| `02_baselines.py` | random forest and logistic regression, identical protocol | Table A5 |
| `03_validation_design.py` | PSU-grouped folds; temporal validation | Table A6 |
| `04_imbalance_ablation.py` | imbalance-strategy ablation; per-class metrics | Tables A1, A2 |
| `05_equal_n_control.py` | equal-sample-size control | Table A3 |
| `06_survey_design.py` | weighted vs unweighted composition; design effects | Table A4, §2.1 |
| `07_config_crosstest.py` | window × configuration; disjoint enrolment blocks | Table A7, §4 |
| `08_attribution_bootstrap.py` | residence attribution with design-bootstrap intervals | Tables 2, 3, 4, 5 |
| `09_figures.py` | all three figures | Figures 1–3 |

### Expected values

Checks a reader can make directly. Script 07 is deterministic and should
reproduce exactly; bootstrap quantities carry Monte Carlo error of the order
of the final digit.

**07 — configuration cross-test** (census region, mean |SHAP|):

| Sample | Config A (200/5/0.05) | Config B (300/4/0.01) |
|:--|--:|--:|
| H1 | 0.0246 | 0.0059 |
| H2 | 0.0290 | 0.0062 |
| H3 | 0.0322 | 0.0062 |

Attribution magnitude tracks the configuration, not the window. This is the
evidence for the paper's methodological argument.

**08 — residence attribution** as a share of total attribution:
region 1.03%, 1.14%, 1.08% across H1/H2/H3, with intervals 0.54–1.87%,
0.56–1.90%, 0.46–1.86%. One of the twenty-four signed contributions in
Table 4 excludes zero.

**01 — nested cross-validation** (macro F1, SD): 0.470 (0.024), 0.484 (0.018),
0.443 (0.024). **02 — baselines:** logistic regression leads at H1 and H3,
gradient boosting at H2; every difference is below its fold SD.
**03 — group folds:** 0.466, 0.461, 0.453, declining monotonically.
**06 — design effects at H1:** 37.3 (rural), 42.8 (non-metropolitan), 3.0
(very low food security).

---

## 4. Method notes

**Common configuration.** All attribution results (Tables 2–5, Figures 2–3,
Table A7) use one hyperparameter configuration at every window — 200 trees,
depth 5, learning rate 0.05. A SHAP magnitude scales with the total
attribution mass of the model that produced it, which depends on the
hyperparameters, so attributions from separately tuned models are not on a
common scale. Table A7 quantifies this: holding the window fixed and changing
only the configuration moves census-region attribution by a factor of three to
five, which exceeds any difference between windows under a fixed
configuration.

**Design bootstrap.** Interval estimates resample primary sampling units
*within strata* and refit the model in each replicate. Both choices matter.
The residence indicators are heavily clustered within PSUs — non-metropolitan
households occupy 13 of the 57 units, rural households 36 — so resampling
households rather than units understates their standard errors severalfold,
and holding the model fixed omits the variability of re-estimation. A
household-level bootstrap of a single fitted model gives intervals narrower by
roughly a factor of forty-five.

**Permutation repetitions.** The full-sample ranking that defines the
predictor panel used R = 30. The in-fold re-derivation inside each outer
training fold uses R = 8, since that selection runs five times per window per
learner; it serves to produce leakage-free performance estimates and to check
the panel's stability, not to define the panel. See `pipeline.R_FULL_SAMPLE`
and `pipeline.R_IN_FOLD`.

**A known inconsistency.** Tables A1–A3 as published use the per-window
hyperparameters from the original tuning (configuration A at H1 and H2,
configuration B at H3), whereas Tables 2–5 and A7 use the common
configuration. Macro F1 is scale-free, so the strategy ranking in Table A1 is
unaffected, but scripts 04 and 05 accept `--config common` to reproduce those
tables under the common configuration for readers who prefer internal
consistency throughout.

**What the design does and does not support.** FAPS measures household food
security once, at the enrolment interview. The three windows are nested
subsets of enrolment month, not lead times to a later observation, and the
outcome modelled in every window is that single contemporaneous measurement.
The code therefore implements a comparison of one procedure across three
nested samples, and supports no claim about forecasting future status. See
§2.3 of the manuscript.

---

## 5. Changes from the previous deposit

This release supersedes the earlier archive. Readers comparing the two should
note the following, all of which affect reported results:

1. **Per-window hyperparameter switch in the attribution analysis.** The
   earlier code tuned each window separately and then compared raw SHAP
   magnitudes between windows. Because attribution magnitude depends on the
   configuration, that comparison produced an apparent peak at three months
   and collapse at six which does not survive a common configuration. Script
   07 documents the effect; Tables 2–5 are now computed under one
   configuration throughout.
2. **Window-partition expression.** The earlier notebooks expressed the
   enrolment-month filter in a form that did not match the stated rule,
   although the resulting partition sizes were correct. The windows are now
   defined once, in `pipeline.WINDOWS`.
3. **Bootstrap procedure.** The earlier intervals resampled households around
   a single fitted model. They are replaced by a stratified design bootstrap
   that resamples PSUs within strata and refits the model.
4. **Survey design.** The design fields are now documented and used for
   interval estimation and for the weighted-versus-unweighted composition,
   rather than only dropped from the predictor pool.
5. **Baseline comparison and design-respecting validation** (scripts 02 and
   03) are new.

---

## 6. Citation

Please cite the manuscript. FAPS data are available from the USDA Economic
Research Service and are not included in this repository.
